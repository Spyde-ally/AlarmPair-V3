# AlarmPair V4

Private two-person synchronized alarm prototype.

## V4 flow
1. Phone A: Create Private Pair → share the 6-digit invite code.
2. Phone B: Join with Invite Code.
3. Both phones show the pairing state and connected partner.
4. Set one shared alarm. Both phones schedule the same server timestamp locally.
5. Alarm → each person presses STOP / I'M UP.
6. When both have stopped: both enter goals. Partner goals are displayed.
7. When both goals are submitted: server waits 5 minutes.
8. Server starts a 30-second wake check. If either misses it, another 30-second check starts.
9. Only after both press I'M HERE does the session become complete.
10. WAKE THE OTHER PERSON sends an attributed wake signal; if the partner is disconnected it is queued until their app reconnects.

## Important reliability note
The Render server currently uses in-memory state. A server restart can lose pairings and scheduled session state. V4 keeps credentials locally and reconnects, but durable production state requires a persistent database/Redis and push delivery (for truly closed-app instant partner wake).
