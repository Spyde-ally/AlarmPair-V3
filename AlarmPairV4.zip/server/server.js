const http = require('http');
const crypto = require('crypto');
const WebSocket = require('ws');

const pairs = new Map();
const deviceIndex = new Map();
const rand = () => crypto.randomBytes(24).toString('base64url');
const inviteCode = () => String(Math.floor(100000 + Math.random() * 900000));

function send(ws, data) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function broadcast(pair, data) { for (const ws of pair.clients.values()) send(ws, data); }
function other(role) { return role === 'A' ? 'B' : 'A'; }
function publicAlarm(p) { return p.alarm ? { ...p.alarm } : null; }
function state(p) {
  return { status:p.status, alarm:publicAlarm(p), goals:p.goals, wakeResponses:p.wakeResponses,
    wakeCheckDeadlineAt:p.wakeCheckDeadlineAt, connected:p.clients.size===2,
    pairReady:p.roles.size===2, pendingManualWake:p.pendingManualWake };
}
function auth(ws) {
  if (!ws.deviceToken) return null;
  const id=deviceIndex.get(ws.deviceToken), p=id&&pairs.get(id);
  return p && p.roles.has(ws.deviceToken) ? p : null;
}
function clearTimer(p) { if(p.timer) clearTimeout(p.timer); p.timer=null; }
function startWake(p) {
  clearTimer(p); p.status='WAKE_CHECK_ACTIVE'; p.wakeResponses={A:false,B:false};
  p.wakeCheckDeadlineAt=Date.now()+30000;
  broadcast(p,{type:'wakeCheck',deadlineAt:p.wakeCheckDeadlineAt,state:state(p)});
  p.timer=setTimeout(()=>{ if(p.status==='WAKE_CHECK_ACTIVE') startWake(p); },30000);
}
function startWait(p) {
  clearTimer(p); p.status='WAITING_5_MIN'; p.wakeCheckDeadlineAt=Date.now()+300000;
  broadcast(p,{type:'state',state:state(p)});
  p.timer=setTimeout(()=>startWake(p),300000);
}
function complete(p) {
  if(p.wakeResponses.A && p.wakeResponses.B){ clearTimer(p); p.status='COMPLETED'; p.wakeCheckDeadlineAt=0; broadcast(p,{type:'sessionComplete',state:state(p)}); }
}
function newPair(ws) {
  const id=rand(), token=rand(), code=inviteCode();
  const p={code,clients:new Map([[token,ws]]),roles:new Map([[token,'A']]),alarm:null,status:'PAIRING',goals:{A:null,B:null},wakeResponses:{A:false,B:false},wakeCheckDeadlineAt:0,pendingManualWake:{A:null,B:null},timer:null};
  pairs.set(id,p); deviceIndex.set(token,id); ws.deviceToken=token; ws.pairId=id; ws.role='A';
  send(ws,{type:'paired',role:'A',deviceToken:token,invite:code,state:state(p)});
}
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:true,service:'AlarmPair v4',pairs:pairs.size}));});
const wss=new WebSocket.Server({server});
wss.on('connection',ws=>{
  ws.deviceToken=null; ws.pairId=null; ws.role=null;
  ws.on('message',raw=>{
    let m; try{m=JSON.parse(raw.toString())}catch{return;}
    if(m.type==='createPair'){ if(!ws.pairId)newPair(ws); return; }
    if(m.type==='joinPair'){
      if(ws.pairId)return;
      const code=String(m.invite||'').trim(); let found;
      for(const [id,p] of pairs) if(p.code===code && p.roles.size===1){found=[id,p];break;}
      if(!found){send(ws,{type:'error',message:'That invite code is invalid or has already been used.'});return;}
      const [id,p]=found, token=rand(); p.code=null; p.clients.set(token,ws); p.roles.set(token,'B');
      deviceIndex.set(token,id); ws.deviceToken=token; ws.pairId=id; ws.role='B';
      send(ws,{type:'paired',role:'B',deviceToken:token,state:state(p)});
      broadcast(p,{type:'pairStatus',connected:true,pairReady:true,state:state(p)}); return;
    }
    if(m.type==='resume'){
      const token=String(m.deviceToken||''), id=deviceIndex.get(token), p=id&&pairs.get(id);
      if(!p||!p.roles.has(token)){send(ws,{type:'error',message:'This pairing is no longer available. Create or join a new pair.'});return;}
      ws.deviceToken=token;ws.pairId=id;ws.role=p.roles.get(token);p.clients.set(token,ws);
      const pending=p.pendingManualWake[ws.role]; p.pendingManualWake[ws.role]=null;
      send(ws,{type:'resumed',role:ws.role,state:state(p)});
      if(pending)send(ws,{type:'manualWake',triggeredBy:pending.triggeredBy,eventId:pending.eventId});
      broadcast(p,{type:'pairStatus',connected:p.clients.size===2,pairReady:true,state:state(p)}); return;
    }
    const p=auth(ws); if(!p){send(ws,{type:'error',message:'Pair the phone first.'});return;}
    if(m.type==='sync'){send(ws,{type:'sync',serverNow:Date.now(),state:state(p)});return;}
    if(m.type==='setAlarm'){
      const target=Number(m.targetAt); if(p.roles.size!==2||p.clients.size!==2){send(ws,{type:'error',message:'Both phones must be connected before setting the shared alarm.'});return;}
      if(!Number.isFinite(target)||target<=Date.now()+1000){send(ws,{type:'error',message:'Invalid alarm time.'});return;}
      clearTimer(p);p.alarm={targetAt:target,active:true,stoppedA:false,stoppedB:false};p.status='SCHEDULED';p.goals={A:null,B:null};p.wakeResponses={A:false,B:false};p.wakeCheckDeadlineAt=0;p.pendingManualWake={A:null,B:null};
      broadcast(p,{type:'alarm',alarm:p.alarm,state:state(p)}); p.timer=setTimeout(()=>{if(p.alarm&&p.alarm.targetAt===target){p.status='RINGING';broadcast(p,{type:'alarmRinging',alarm:p.alarm,state:state(p)});}},Math.max(0,target-Date.now())); return;
    }
    if(m.type==='stop'){
      if(!p.alarm||!p.alarm.active)return; if(ws.role==='A')p.alarm.stoppedA=true;else p.alarm.stoppedB=true;
      if(p.alarm.stoppedA&&p.alarm.stoppedB){p.alarm.active=false;p.status='AWAITING_GOALS';clearTimer(p);p.wakeCheckDeadlineAt=0;}
      broadcast(p,{type:'alarm',alarm:p.alarm,state:state(p)});return;
    }
    if(m.type==='submitGoals'){
      if(!['AWAITING_GOALS','GOALS'].includes(p.status))return; const text=String(m.text||'').trim().slice(0,2000);if(!text){send(ws,{type:'error',message:'Goals cannot be empty.'});return;}
      p.goals[ws.role]=text;p.status='GOALS';broadcast(p,{type:'goals',text,from:ws.role,state:state(p)});if(p.goals.A&&p.goals.B)startWait(p);return;
    }
    if(m.type==='confirmHere'){
      if(p.status!=='WAKE_CHECK_ACTIVE')return;p.wakeResponses[ws.role]=true;broadcast(p,{type:'hereConfirmed',from:ws.role,state:state(p)});complete(p);return;
    }
    if(m.type==='manualWake'){
      const r=other(ws.role),event={triggeredBy:`Device ${ws.role}`,eventId:rand()},partner=[...p.clients.entries()].find(([t])=>p.roles.get(t)===r)?.[1];
      if(partner)send(partner,{type:'manualWake',...event});else p.pendingManualWake[r]=event;
      send(ws,{type:'manualWakeSent',queued:!partner,to:r});return;
    }
  });
  ws.on('close',()=>{const p=ws.pairId&&pairs.get(ws.pairId);if(!p||!ws.deviceToken)return;if(p.clients.get(ws.deviceToken)===ws)p.clients.delete(ws.deviceToken);broadcast(p,{type:'pairStatus',connected:p.clients.size===2,pairReady:p.roles.size===2,state:state(p)});});
});
const PORT=process.env.PORT||8080;server.listen(PORT,'0.0.0.0',()=>console.log(`AlarmPair v4 listening on ${PORT}`));
