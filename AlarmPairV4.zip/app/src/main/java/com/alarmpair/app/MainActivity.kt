package com.alarmpair.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var tvStatus: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var tvClock: TextView
    private lateinit var panelPairing: LinearLayout
    private lateinit var panelAlarm: LinearLayout
    private lateinit var panelAlarmActive: LinearLayout
    private lateinit var panelGoals: LinearLayout
    private lateinit var panelWakeCheck: LinearLayout
    private lateinit var panelWakeOther: LinearLayout
    private lateinit var btnCreatePair: Button
    private lateinit var btnJoinPair: Button
    private lateinit var btnSetAlarm: Button
    private lateinit var btnStop: Button
    private lateinit var btnSubmitGoals: Button
    private lateinit var btnImHere: Button
    private lateinit var btnWakeOther: Button
    private lateinit var timePicker: TimePicker
    private lateinit var etGoals: EditText
    private lateinit var tvGoalsStatus: TextView
    private lateinit var tvPartnerGoalsLabel: TextView
    private lateinit var tvPartnerGoals: TextView
    private lateinit var tvAlarmActiveInfo: TextView
    private lateinit var tvWakeCheckTimer: TextView
    private lateinit var tvManualWakeInfo: TextView

    private val prefs by lazy { getSharedPreferences("alarmpair_v4", MODE_PRIVATE) }
    private lateinit var ws: WsManager
    private val handler = Handler(Looper.getMainLooper())
    private var role = ""
    private var token = ""
    private var serverOffset = 0L
    private var connected = false
    private var pairReady = false
    private var status = "IDLE"
    private var alarmTarget = 0L
    private var alarmActive = false
    private var stoppedMe = false
    private var stoppedPartner = false
    private var myGoals = false
    private var partnerGoals = false
    private var myHere = false
    private var partnerHere = false
    private var wakeDeadline = 0L

    private val tick = object : Runnable {
        override fun run() {
            tvClock.text = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
            if (alarmTarget > 0) tvCountdown.text = formatMs(alarmTarget - (System.currentTimeMillis() + serverOffset))
            if (status == "WAKE_CHECK_ACTIVE" && wakeDeadline > 0) {
                val sec = max(0, (wakeDeadline - (System.currentTimeMillis() + serverOffset)) / 1000)
                tvWakeCheckTimer.text = if (myHere) "You confirmed. Waiting for partner…" else "Confirm in ${sec}s or we'll ask again"
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        migrateOldPrefsIfNeeded()
        requestPermissions()
        setupButtons()

        token = prefs.getString("deviceToken", "") ?: ""
        role = prefs.getString("role", "") ?: ""
        alarmTarget = prefs.getLong("alarmTargetAt", 0L)

        ws = WsManager(
            BuildConfig.SERVER_URL,
            ::handleMessage,
            { connected = true; tvStatus.text = if (pairReady) "🟢 Both phones connected" else if (token.isBlank()) "🟢 Server connected — create or join a pair" else "🟡 Reconnecting to your pair…"; updatePanels() },
            { connected = false; tvStatus.text = "🔴 Connection lost — retrying…"; updatePanels() }
        )
        ws.setDeviceToken(token)
        ws.connect()
        handler.post(tick)
        updatePanels()
    }

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus); tvCountdown = findViewById(R.id.tvCountdown); tvClock = findViewById(R.id.tvClock)
        panelPairing = findViewById(R.id.panelPairing); panelAlarm = findViewById(R.id.panelAlarm); panelAlarmActive = findViewById(R.id.panelAlarmActive)
        panelGoals = findViewById(R.id.panelGoals); panelWakeCheck = findViewById(R.id.panelWakeCheck); panelWakeOther = findViewById(R.id.panelWakeOther)
        btnCreatePair = findViewById(R.id.btnCreatePair); btnJoinPair = findViewById(R.id.btnJoinPair); btnSetAlarm = findViewById(R.id.btnSetAlarm)
        btnStop = findViewById(R.id.btnStop); btnSubmitGoals = findViewById(R.id.btnSubmitGoals); btnImHere = findViewById(R.id.btnImHere); btnWakeOther = findViewById(R.id.btnWakeOther)
        timePicker = findViewById(R.id.timePicker); etGoals = findViewById(R.id.etGoals); tvGoalsStatus = findViewById(R.id.tvGoalsStatus)
        tvPartnerGoalsLabel = findViewById(R.id.tvPartnerGoalsLabel); tvPartnerGoals = findViewById(R.id.tvPartnerGoals); tvAlarmActiveInfo = findViewById(R.id.tvAlarmActiveInfo)
        tvWakeCheckTimer = findViewById(R.id.tvWakeCheckTimer); tvManualWakeInfo = findViewById(R.id.tvManualWakeInfo)
    }

    private fun migrateOldPrefsIfNeeded() {
        if (prefs.getString("deviceToken", null) == null) {
            val old = getSharedPreferences("alarmpair_v3", MODE_PRIVATE)
            val oldToken = old.getString("deviceToken", "") ?: ""
            val oldRole = old.getString("role", "") ?: ""
            if (oldToken.isNotBlank()) prefs.edit().putString("deviceToken", oldToken).putString("role", oldRole).apply()
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 42)
        if (Build.VERSION.SDK_INT >= 31) try {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        } catch (_: Exception) {}
    }

    private fun setupButtons() {
        btnCreatePair.setOnClickListener {
            btnCreatePair.isEnabled = false
            tvStatus.text = "Creating your private pair…"
            ws.send(JSONObject().put("type", "createPair"))
        }
        btnJoinPair.setOnClickListener { joinDialog() }
        btnSetAlarm.setOnClickListener { setAlarm() }
        btnStop.setOnClickListener { stopAlarmForMe() }
        btnSubmitGoals.setOnClickListener { submitGoals() }
        btnImHere.setOnClickListener { confirmHere() }
        btnWakeOther.setOnClickListener { ws.send(JSONObject().put("type", "manualWake")) }
    }

    private fun handleMessage(m: JSONObject) {
        when (m.optString("type")) {
            "paired" -> {
                role = m.optString("role", role); token = m.optString("deviceToken", token)
                prefs.edit().putString("role", role).putString("deviceToken", token).apply()
                ws.setDeviceToken(token)
                pairReady = m.optJSONObject("state")?.optBoolean("pairReady", false) ?: false
                val invite = m.optString("invite", "")
                if (invite.isNotBlank()) showInvite(invite)
                applyState(m.optJSONObject("state"))
            }
            "resumed" -> { role = m.optString("role", role); applyState(m.optJSONObject("state")); ws.send(JSONObject().put("type", "sync")) }
            "sync" -> { serverOffset = m.optLong("serverNow", System.currentTimeMillis()) - System.currentTimeMillis(); applyState(m.optJSONObject("state")) }
            "state" -> applyState(m.optJSONObject("state"))
            "pairStatus" -> { connected = m.optBoolean("connected", false); pairReady = m.optBoolean("pairReady", pairReady); applyState(m.optJSONObject("state")) }
            "alarm", "alarmRinging" -> { m.optJSONObject("alarm")?.let(::applyAlarm); applyState(m.optJSONObject("state")) }
            "goals" -> { if (m.optString("from") != role) { partnerGoals = true; tvPartnerGoalsLabel.visibility = View.VISIBLE; tvPartnerGoals.visibility = View.VISIBLE; tvPartnerGoals.text = m.optString("text"); updateGoalText() } }
            "wakeCheck" -> { wakeDeadline = m.optLong("deadlineAt", 0); status = "WAKE_CHECK_ACTIVE"; myHere = false; showWake() }
            "hereConfirmed" -> { if (m.optString("from") != role) { partnerHere = true; updateWake() } }
            "sessionComplete" -> { status = "COMPLETED"; wakeDeadline = 0; panelWakeCheck.visibility = View.GONE; tvStatus.text = "✅ Both confirmed — session complete"; tvCountdown.text = "DONE"; updatePanels() }
            "manualWake" -> { val by = m.optString("triggeredBy", "Your partner"); tvManualWakeInfo.text = "⚠️ $by is waking you up!"; tvManualWakeInfo.visibility = View.VISIBLE; ringManualWake(by) }
            "manualWakeSent" -> { tvManualWakeInfo.text = if (m.optBoolean("queued")) "Wake queued — it will be delivered when your partner reconnects." else "Wake signal sent to your partner!"; tvManualWakeInfo.visibility = View.VISIBLE }
            "error" -> handleError(m.optString("message"))
        }
    }

    private fun handleError(message: String) {
        if (message.contains("pairing", true) || message.contains("pair the phone", true) || message.contains("no longer available", true)) {
            token = ""; role = ""; pairReady = false; connected = true
            prefs.edit().clear().apply(); ws.setDeviceToken("")
            tvStatus.text = "🟢 Server connected — create a new private pair"
            updatePanels()
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        btnCreatePair.isEnabled = true
    }

    private fun applyState(s: JSONObject?) {
        if (s == null) return
        connected = s.optBoolean("connected", connected)
        pairReady = s.optBoolean("pairReady", pairReady)
        status = s.optString("status", status)
        wakeDeadline = s.optLong("wakeCheckDeadlineAt", wakeDeadline)
        val goals = s.optJSONObject("goals")
        if (goals != null && role.isNotBlank()) { val other = if (role == "A") "B" else "A"; myGoals = goals.optString(role, null) != null; partnerGoals = goals.optString(other, null) != null }
        val wr = s.optJSONObject("wakeResponses")
        if (wr != null && role.isNotBlank()) { myHere = wr.optBoolean(role, false); partnerHere = wr.optBoolean(if (role == "A") "B" else "A", false) }
        s.optJSONObject("alarm")?.let(::applyAlarm)
        when (status) {
            "PAIRING" -> { panelPairing.visibility = View.VISIBLE; tvStatus.text = "🟡 Waiting for the second phone…" }
            "AWAITING_GOALS", "GOALS", "WAITING_5_MIN" -> showGoals()
            "WAKE_CHECK_ACTIVE" -> showWake()
            "COMPLETED" -> { panelWakeCheck.visibility = View.GONE; panelGoals.visibility = View.GONE }
        }
        updateGoalText(); updateWake(); updatePanels()
    }

    private fun applyAlarm(a: JSONObject) {
        alarmTarget = a.optLong("targetAt", 0); alarmActive = a.optBoolean("active", false)
        stoppedMe = if (role == "A") a.optBoolean("stoppedA") else a.optBoolean("stoppedB")
        stoppedPartner = if (role == "A") a.optBoolean("stoppedB") else a.optBoolean("stoppedA")
        prefs.edit().putLong("alarmTargetAt", alarmTarget).apply()
        if (alarmActive) { scheduleLocalAlarm(max(System.currentTimeMillis() + 1000, alarmTarget - serverOffset)); btnStop.isEnabled = !stoppedMe }
        else { cancelLocalAlarm(); btnStop.isEnabled = false }
        updatePanels()
    }

    private fun showInvite(code: String) {
        AlertDialog.Builder(this).setTitle("🔐 Private Pair Created")
            .setMessage("Give this 6-digit code to the other person:\n\n$code\n\nIt can be used only once.")
            .setPositiveButton("Copy Code") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("AlarmPair invite", code))
            }.setNegativeButton("Done", null).show()
    }

    private fun joinDialog() {
        val e = EditText(this).apply { hint = "6-digit invite code"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; maxLines = 1 }
        AlertDialog.Builder(this).setTitle("Join Private Pair").setMessage("Enter the code from the first phone.").setView(e)
            .setPositiveButton("JOIN") { _, _ -> val code=e.text.toString().trim(); if(code.length!=6) Toast.makeText(this,"Enter the 6-digit code.",Toast.LENGTH_SHORT).show() else { btnJoinPair.isEnabled=false; ws.send(JSONObject().put("type","joinPair").put("invite",code)) } }
            .setNegativeButton("Cancel") { _, _ -> btnJoinPair.isEnabled=true }.show()
    }

    private fun setAlarm() {
        if (role.isBlank() || !pairReady || !connected) { Toast.makeText(this, "Both phones must be connected first.", Toast.LENGTH_SHORT).show(); return }
        val c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY, timePicker.hour); c.set(Calendar.MINUTE, timePicker.minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DATE, 1)
        ws.send(JSONObject().put("type", "setAlarm").put("targetAt", c.timeInMillis + serverOffset))
    }

    private fun stopAlarmForMe() {
        if (stoppedMe) return
        stoppedMe=true; btnStop.isEnabled=false; cancelLocalAlarm(); ws.send(JSONObject().put("type","stop"));
        if(!stoppedPartner) tvStatus.text="⏳ You are up. Waiting for your partner…"
    }

    private fun showGoals() { panelAlarmActive.visibility=View.GONE; panelGoals.visibility=View.VISIBLE; panelWakeOther.visibility=View.VISIBLE; tvStatus.text="🎯 Both awake — enter today's goals" }
    private fun submitGoals() { val text=etGoals.text.toString().trim(); if(text.isBlank()){Toast.makeText(this,"Write at least one goal.",Toast.LENGTH_SHORT).show();return}; myGoals=true; btnSubmitGoals.isEnabled=false; ws.send(JSONObject().put("type","submitGoals").put("text",text)); updateGoalText() }
    private fun updateGoalText() { tvGoalsStatus.text="You: ${if(myGoals)"✓ submitted" else "⏳ not submitted"}   |   Partner: ${if(partnerGoals)"✓ submitted" else "⏳ waiting"}"; if(status=="WAITING_5_MIN") tvGoalsStatus.text="✓ Both goals received. Wake check starts in 5 minutes." }
    private fun showWake() { panelGoals.visibility=View.GONE; panelWakeCheck.visibility=View.VISIBLE; panelWakeOther.visibility=View.VISIBLE; btnImHere.isEnabled=!myHere; btnImHere.text=if(myHere)"Confirmed ✓" else "I'M HERE ✓"; updateWake() }
    private fun updateWake() { if(status=="WAKE_CHECK_ACTIVE"){panelWakeCheck.visibility=View.VISIBLE; if(myHere) tvWakeCheckTimer.text="You confirmed. Waiting for partner…"; if(myHere&&partnerHere)panelWakeCheck.visibility=View.GONE} }
    private fun confirmHere(){if(myHere)return;myHere=true;btnImHere.isEnabled=false;ws.send(JSONObject().put("type","confirmHere"));updateWake()}

    private fun ringManualWake(by: String) { sendBroadcast(Intent(this, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_MANUAL_WAKE).putExtra("triggeredBy", by)) }

    private fun scheduleLocalAlarm(at:Long){val am=getSystemService(AlarmManager::class.java);val pi=PendingIntent.getBroadcast(this,AlarmReceiver.NOTIF_ID_ALARM,Intent(this,AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_ALARM),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);try{if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)else am.setExact(AlarmManager.RTC_WAKEUP,at,pi)}catch(_:SecurityException){am.set(AlarmManager.RTC_WAKEUP,at,pi)}}
    private fun cancelLocalAlarm(){val am=getSystemService(AlarmManager::class.java);val pi=PendingIntent.getBroadcast(this,AlarmReceiver.NOTIF_ID_ALARM,Intent(this,AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_ALARM),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.cancel(pi)}

    private fun updatePanels(){
        val paired=token.isNotBlank();
        panelPairing.visibility=if(paired)View.GONE else View.VISIBLE
        btnCreatePair.isEnabled=!paired
        btnJoinPair.isEnabled=!paired
        panelAlarm.visibility=if(paired&&pairReady&&!alarmActive&&status!="COMPLETED"&&status!="PAIRING")View.VISIBLE else View.GONE
        panelAlarmActive.visibility=if(alarmActive)View.VISIBLE else View.GONE
        tvAlarmActiveInfo.text=when{!alarmActive->"";stoppedMe->"⏳ You are up — waiting for your partner…";else->"🔔 ALARM — STOP / I'M UP"}
        if(paired&&!pairReady&&status=="PAIRING")tvStatus.text="🟡 Private pair created — waiting for the second phone"
        if(paired&&pairReady&&connected&&status!="PAIRING")tvStatus.text=if(status=="SCHEDULED")"🟢 Both phones connected — alarm scheduled" else tvStatus.text
    }

    private fun formatMs(ms:Long):String{val t=max(0,ms/1000);val h=t/3600;val m=(t%3600)/60;val s=t%60;return if(h>0)"%02d:%02d:%02d".format(h,m,s)else"%02d:%02d".format(m,s)}
    override fun onDestroy(){handler.removeCallbacks(tick);ws.disconnect();super.onDestroy()}
}
